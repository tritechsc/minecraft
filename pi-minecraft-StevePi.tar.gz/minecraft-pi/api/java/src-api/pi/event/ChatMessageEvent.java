package pi.event;

/**
 *
 * @author Daniel Frisk, twitter:danfrisk
 */
class ChatMessageEvent {

}
