This version of Minecraft-Pi was copied from /opt/minecraft-pi

The mcpi-start file is the shortcut copied from /usr/bin/minecraft-pi

The script was modified to work from the Desktop sop StevePi could be 
changed using a hexedit.

CW Coleman
