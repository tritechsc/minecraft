print ("Hello World")
